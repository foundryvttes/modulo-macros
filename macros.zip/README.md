# modulo-macros
[Módulo] Recopilatorio de macros
